package com.example.agoraproject.appinterfaces;

public interface ShoppingCartInterface {
    void onItemClicked(int pos);
    void onDeleteClick(int pos);
    void onChatClick(int pos);
}

package com.example.agoraproject.appinterfaces;

public interface FaveItemRVInterface {
    void onItemClicked(int pos);
    void onDeleteClick(int pos);
}

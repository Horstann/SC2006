package com.example.agoraproject.appinterfaces;

public interface ManagePageRVInterface {
    void onItemClicked(int pos);
    void onDeleteClick(int pos);
    void onChatClick(int pos);
    void onEditClick(int pos);
}

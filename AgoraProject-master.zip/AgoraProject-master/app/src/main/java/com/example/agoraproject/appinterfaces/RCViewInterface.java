package com.example.agoraproject.appinterfaces;

public interface RCViewInterface {
    void onItemClick(int Position);
}
